const Token = document.querySelector("script[csrf]").getAttribute('csrf')

export {Token}
