export default {
    name: 'Version',
    template: `<div class="slims-version">SLiMS version 9 &mdash; Bulian</div>`
}