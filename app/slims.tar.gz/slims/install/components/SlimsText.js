export default {
    name: 'SlimsText',
    template: `<span>SL<span class="text-yellow-600">i</span>MS</span>`
}