export default {
    name: 'SlimsTextVertical',
    template: `<div class="flex flex-col items-center">
<div>S</div>
<div>L</div>
<div class="text-yellow-500">i</div>
<div>M</div>
<div>S</div>
</div>`
}