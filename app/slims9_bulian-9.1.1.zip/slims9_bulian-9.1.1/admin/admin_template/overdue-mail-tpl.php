<p>
<?php echo __('To <strong><!--MEMBER_NAME--> (<!--MEMBER_ID-->)</strong>
This is notification e-mail to inform you that you have <strong>OVERDUED</strong> library loan,
the overdued collection(s) are:'); ?>
</p>

<!--OVERDUE_DATA-->

<p>
<?php echo __('Please return all overdued collections immediately to library. If you have
any complaint regarding to this overdue notification,
please contact our circulation desk.'); ?>
</p>

<?php echo __('<p>Thank You.</p>

<strong><!--DATE--></strong>
<br />Library Management'); ?>
