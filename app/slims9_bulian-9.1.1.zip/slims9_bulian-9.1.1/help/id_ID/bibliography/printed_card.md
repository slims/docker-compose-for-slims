####Cetak Kartu Katalog
<hr>
Fitur ini dapat digunakan untuk mencetak kartu katalog.
Cara mencetak hampir sama dengan cara mencetak barcode atau label buku.
