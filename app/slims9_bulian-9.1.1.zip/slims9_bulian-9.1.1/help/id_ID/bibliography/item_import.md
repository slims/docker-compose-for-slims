####Import Item
<hr>
Item import digunakan untuk memasukkan data item ke database SLiMS. Jika kegiatan ini dilakukan dari database SLiMS yang satu ke SLiMS yang lain, maka item import dilakukan setelah bibliography import. Artinya item akan menyesuaikan data bibliografi yang telah diimport lebih dahulu.
