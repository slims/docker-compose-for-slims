#### Checkout items
<hr>
This menu provides information about the item being borrowed. This menu is also equipped with a search facility to find bibliographic items and titles. The information contained in this menu is: 
- Item Code, 
- Member ID Borrower, 
- Title, 
- Loan Date (when lent), 
- Due Date (date of return).
