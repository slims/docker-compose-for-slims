###Membership Report

Contains membership information, ie:
- Total registered members, 
- Total active members, 
- Total members by members type, 
- Total members who are not active and a list of 10 (ten) most active members.

The report is available in .html format and can be printed by clicking Download Report

Commencing Senayan3-stable14, the three types of report are equipped with a print feature of various Pie charts. You get this graph simply by clicking the “Show in Chart/Plot“ which appears in all three types of report (Statistics Collection, Loan Report, and Membership Report).
