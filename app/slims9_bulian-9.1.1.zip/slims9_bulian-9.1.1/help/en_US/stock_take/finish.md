### Finish StockTake
<hr>
Click on this link if you have finished stock-taking. In the menu, there is a field labelled Purge Lost Item. If we give a checkmark on Yes, the data items in the collection that are in Current Lost items will be marked as "Missing".
