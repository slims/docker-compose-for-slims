###Grupos de usuarios

Una funcionalidad para definir los grupos de usuarios. Aquí, puede crear grupos de usuarios en su sistema y otorgar permisos de lectura (Read) o Escritura (Write) para los módulos de Senayan. Cada usuario puede ser ubicado en más de un grupo.