###Contenido

Este menú se utiliza para cambiar la apariencia del contenido de la aplicación de Senayan. De forma predeterminada, las vistas que ya existen y que se pueden modificar en este menú son:
- Información de la página de inicio, ubicada en la parte frontal del OPAC [que se muestra cuando se hace clic en "Inicio"],
- Bienvenida a la página de administración [la pantalla inicial al ingresar al menú de administración (Consola de Administración de Senayan)],
- Ayuda para la búsqueda [disponible desde el OPAC], y
- Información de la biblioteca [también se accede desde el OPAC].

Considere una ruta ya creada para el nuevo contenido como 'bibliotecario'. Para mostrar este contenido con la ruta antes definida, necesitamos escribir la url:

http://localhost/slims/index.php?p=bibliotecario

Podemos también crear el enlace de navegación a esta URL en el OPAC editando la plantilla correspondiente.