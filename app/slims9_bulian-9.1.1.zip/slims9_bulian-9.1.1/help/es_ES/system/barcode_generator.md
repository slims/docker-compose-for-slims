###Generador de códigos de barras

Ingrese el código que se convertirá en un código de barras en las columnas de la pantalla. Determine el tamaño del código de barras (pequeño, mediano o grande) y haga clic en Generar código de barras. Luego se verá en forma de un código de barras, en HTML y que se puede imprimir en una impresora. La codificación predeterminada utilizada es el código de barras 128B. Puede modificar esta codificación del código de barras en el archivo de configuración global de Senayan, sysconfig.inc.php.

Nota:
Los caracteres que se pueden procesar con el generador de códigos de barras son solamente el conjunto de los caracteres alfanuméricos.