###Usuarios del sistema

Una funcionalidad para determinar qué usuarios pueden acceder al sistema, de acuerdo con sus permisos. Estos usuarios podrán realizar un inicio de sesión según su nombre de usuario y contraseña respectivamente. Este menú contiene las opciones:

- Añadir nuevo usuario,
- Lista de usuarios,
- Búsqueda (búscar a un usuario específico),
- Editar y Eliminar al usuario.

Dentro de la información del usuario, también se pueden agregar sus credenciales de Internet, por ejemplo: perfil de Facebook, blog o sitios web, etc.

Para agregar un usuario, haga clic en Agregar nuevo usuario y luego ingrese el nombre de usuario, su nombre real, los grupos (a los que pertenecerá) y la contraseña.
