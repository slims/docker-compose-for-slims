###Subir lista
<hr>
Este menú se utiliza para realizar un inventario automatizado usando un archivo de datos que enumera los ejemplares. Para poder usar este menú, primero se deben exportar los datos de los ejemplares desde Senayan, luego los ejemplares específicos se almacenarán en filas en un archivo TXT.