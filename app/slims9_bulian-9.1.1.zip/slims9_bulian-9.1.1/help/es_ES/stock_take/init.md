####Inicializar
<hr>
El menú Inicializar se utiliza para iniciar el inventario. En este menú, estarán los siguientes submenús:
- Nombre del inventario: el nombre de las actividades de inventario realizadas. Personaliza el nombre a tu gusto. Este campo DEBE llenarse.
- DGM: (Consulte la guía del módulo Archivo maestro -> DGM (debajo de Archivos de autoridad)).
- Tipo de colección: (Consulte la guía del módulo Archivo maestro -> Tipo de colección (en Búsqueda de archivos)).
- Ubicación: (Consulte la guía del módulo Archivo maestro -> Ubicación (debajo de Archivos de autoridad)).
- Ubicación del estante: refiriéndose a la información del ejemplar en el módulo de Catalogación.
- Clasificación: Refiriéndose al campo de clasificación en el módulo de Catalogación. Para definir un rango de clasificación use el comodín (*). Por ejemplo, si queremos hacer un inventario de las clasificaciones con un rango del 100 al 300, solo ingrese 1* a 3*. Si el rango de clasificaciones que inventariamos es el 100, inserte 1*.

Una vez finalizada la Inicialización, el menú Inventario actual y el Informe de inventario servirán como menús para las actividades del chequeo de las existencias, junto con el menú de navegación que se utilizará para realizar el inventario, así como los menúes Finalizar inventario, Ejemplares perdidos, Registro del inventario y Volver a sincronizar.