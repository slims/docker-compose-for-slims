###Lista de títulos

Contiene informes de títulos en poder de la biblioteca. En este menú hay una facilidad para ordenar e imprimir, así como una colección de filtros deseados. El filtrado también se puede hacer escribiendo el Título/ISBN, o mediante la aplicación de otros filtros. Para ello, haga clic en Mostrar más opciones de filtro. Los filtros existentes son:
- Título/ISBN,
- Autor,
- Clasificación,
- GMD,
- Idioma, y
- Ubicación,

y se puede especificar por el número de páginas vistas.