### Estadísticas de uso de los ejemplares

Este es un informe que enumera los ejemplares, y cuántas veces se han prestado los mismo mensualmente. El uso de los ejemplares también puede filtrarse por:
- Título/ISBN,
- Código del ejemplar, o
- Año.