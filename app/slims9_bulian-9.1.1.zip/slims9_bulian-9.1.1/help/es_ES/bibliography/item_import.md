#### Importar ejemplares
<hr>
La importación de ejemplares se utiliza para insertar los datos de los mismos en una base de datos SLiMS. Si esta actividad se realiza desde una única base de datos SLiMS a otra, entonces la importación de los ejemplares se realiza después de la importación bibliográfica. Esto significa que el ejemplar se ajustará a los datos bibliográficos que se han importado anteriormente.
