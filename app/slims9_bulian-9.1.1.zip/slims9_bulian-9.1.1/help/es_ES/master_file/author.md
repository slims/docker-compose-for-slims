#### Archivo maestro / Autor
<hr>
Nombre del autor y tipo de autor (individual o grupal)