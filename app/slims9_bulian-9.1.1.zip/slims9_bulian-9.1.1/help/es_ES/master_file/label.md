#### Archivo maestro / Etiqueta
<hr>
Proporciona información específica sobre el ejemplar bibliográfico. Las etiquetas se pueden definir a través del menú Archivo maestro. Por defecto Senayan tiene tres etiquetas:
- Nuevo título,
- Título favorito, y
- Multimedia.