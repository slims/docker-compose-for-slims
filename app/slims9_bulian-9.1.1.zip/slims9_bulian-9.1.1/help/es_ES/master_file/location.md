#### Archivo maestro / Ubicación
<hr>
Código de la ubicación y el nombre de la misma donde se coloca el ejemplar
Por ejemplo: Biblioteca de la Facultad de Ingeniería