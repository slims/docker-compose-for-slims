####Tipo de miembro

Aquí se definen los tipos de membresía. El tipo de membresía controla los parámetros:
- Límite de préstamo (número máximo de ejemplares prestados),
- Período de préstamo (la duración de un préstamo),
- Reserva (si se pueden hacer reservas),
- Límite de reserva (número máximo de ejemplares reservados),
- Período de la membresía (duración de tiempo de la membresía),
- Límite de las extensiones (límites para extender los préstamos),
- Multa para cada día (multa por cada día de retraso en la devolución), y
- Período de gracia para el atraso (tolerancia en días para las devoluciones tardías).

Para agregar un nuevo tipo de miembro, haga clic en el botón Agregar un nuevo tipo de miembro y continúe llenando todos los campos proporcionados como se mencionó anteriormente.